
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { QuizDifficulty, QuizType, QuizQuestion, Flashcard, ChatMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getChatSession = (history: ChatMessage[] = []): Chat => {
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are Dot AI, a friendly and highly intelligent student assistant. Your goal is to help students understand complex concepts. Use simple metaphors and keep explanations clear. You can suggest quizzes or flashcards if appropriate.",
    },
    // Map internal message format to SDK format if needed
  });
};

export const explainContent = async (content: string, media?: { data: string, mimeType: string }) => {
  const model = 'gemini-3-flash-preview';
  
  const parts: any[] = [{ text: `Explain this following content clearly to a student. Use formatting like bold text and bullet points for readability. Content: ${content}` }];

  if (media) {
    parts.push({
      inlineData: {
        data: media.data.split(',')[1],
        mimeType: media.mimeType
      }
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
  });

  return response.text || "No explanation could be generated.";
};

export const generateQuiz = async (
  context: string, 
  count: number, 
  difficulty: QuizDifficulty, 
  type: QuizType,
  grade: string
): Promise<QuizQuestion[]> => {
  const model = 'gemini-3-flash-preview';

  const response = await ai.models.generateContent({
    model,
    contents: `Generate a ${type} quiz for a student in grade ${grade}. 
      Difficulty: ${difficulty}. 
      Number of questions: ${count}. 
      Based on this context: ${context}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            question: { type: Type.STRING },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Only provide this for multiple choice quizzes" 
            },
            correctAnswer: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ["id", "question", "correctAnswer", "explanation"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
};

export const generateFlashcards = async (context: string): Promise<Flashcard[]> => {
  const model = 'gemini-3-flash-preview';
  const response = await ai.models.generateContent({
    model,
    contents: `Extract the key concepts from the following text and turn them into a set of 10 study flashcards. 
      Context: ${context}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            front: { type: Type.STRING, description: "The term or question" },
            back: { type: Type.STRING, description: "The definition or answer" }
          },
          required: ["id", "front", "back"]
        }
      }
    }
  });
  return JSON.parse(response.text || "[]");
};

export const analyzeResults = async (
  questions: QuizQuestion[], 
  userAnswers: Record<number, string>
): Promise<{ analysis: string, studyGuide: string }> => {
  const model = 'gemini-3-pro-preview';

  const prompt = `Analyze these quiz results and prepare a study guide.
    Questions: ${JSON.stringify(questions)}
    User Answers: ${JSON.stringify(userAnswers)}
    Provide two sections: 1. Analysis of what was correct/incorrect and why. 2. A personalized study guide.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: { type: Type.STRING },
          studyGuide: { type: Type.STRING }
        },
        required: ["analysis", "studyGuide"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};
