
import React from 'react';
import { AppSettings } from '../types';

interface SettingsProps {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, setSettings }) => {
  return (
    <div className="max-w-3xl mx-auto py-20 px-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-12">
        <h1 className="text-5xl font-black text-white mb-3 gradient-text">Settings</h1>
        <p className="text-gray-500 text-lg font-medium">Fine-tune your personal study space</p>
      </div>

      <div className="space-y-8">
        <section className="glass-card p-10 rounded-[3rem]">
          <h2 className="text-2xl font-black mb-8 flex items-center gap-3">
            ✨ Atmosphere
          </h2>
          
          <div className="space-y-5">
            <div className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-white/10 transition-all">
              <div>
                <p className="font-black text-lg">Snow Effect</p>
                <p className="text-sm text-gray-500">Enable a calm, falling snow animation</p>
              </div>
              <button 
                onClick={() => setSettings({...settings, snowEffect: !settings.snowEffect})}
                className={`w-16 h-9 rounded-full transition-all flex items-center px-1.5 ${settings.snowEffect ? 'gradient-bg' : 'bg-white/10'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-all ${settings.snowEffect ? 'translate-x-7' : 'translate-x-0'}`} />
              </button>
            </div>

            <div className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-white/10 transition-all">
              <div>
                <p className="font-black text-lg">Mouse Interaction</p>
                <p className="text-sm text-gray-500">Particles react to your cursor movement</p>
              </div>
              <button 
                onClick={() => setSettings({...settings, mouseInteraction: !settings.mouseInteraction})}
                className={`w-16 h-9 rounded-full transition-all flex items-center px-1.5 ${settings.mouseInteraction ? 'gradient-bg' : 'bg-white/10'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-all ${settings.mouseInteraction ? 'translate-x-7' : 'translate-x-0'}`} />
              </button>
            </div>
          </div>
        </section>

        <section className="glass-card p-10 rounded-[3rem]">
          <h2 className="text-2xl font-black mb-8 flex items-center gap-3 text-white">
            Reset Experience
          </h2>
          <p className="text-gray-500 mb-8">Want to start over? This will clear your profile and history.</p>
          <button 
            onClick={() => {
              if (confirm("Are you sure you want to reset everything? Your data will be permanently deleted.")) {
                localStorage.clear();
                window.location.reload();
              }
            }}
            className="w-full py-6 bg-red-500/10 border border-red-500/20 text-red-500 font-black rounded-3xl hover:bg-red-500 hover:text-white transition-all text-lg"
          >
            CLEAR ALL DATA
          </button>
        </section>
      </div>
    </div>
  );
};

export default Settings;
