
import React, { useEffect, useRef } from 'react';
import { AppSettings } from '../types';

interface BackgroundEffectsProps {
  settings: AppSettings;
}

const BackgroundEffects: React.FC<BackgroundEffectsProps> = ({ settings }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: any[] = [];
    let mouseTrails: any[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resize);
    resize();

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
      if (settings.mouseInteraction) {
        mouseTrails.push({
          x: e.clientX,
          y: e.clientY,
          size: Math.random() * 2 + 1,
          life: 1.0,
          color: `hsla(45, 70%, 70%, ` 
        });
      }
    };
    window.addEventListener('mousemove', handleMouseMove);

    const createSnow = () => {
      particles = [];
      for (let i = 0; i < 40; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: Math.random() * 1.0 + 0.2,
          size: Math.random() * 1.5 + 0.5
        });
      }
    };

    createSnow();

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (settings.snowEffect) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        particles.forEach(p => {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();

          p.x += p.vx;
          p.y += p.vy;

          if (p.y > canvas.height) {
            p.y = -10;
            p.x = Math.random() * canvas.width;
          }
        });
      }

      // Very subtle radial glow around mouse
      const gradient = ctx.createRadialGradient(
        mouseRef.current.x, mouseRef.current.y, 0,
        mouseRef.current.x, mouseRef.current.y, 150
      );
      gradient.addColorStop(0, 'rgba(212, 175, 55, 0.04)');
      gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (settings.mouseInteraction) {
        mouseTrails.forEach((t, i) => {
          t.life -= 0.02;
          if (t.life <= 0) {
            mouseTrails.splice(i, 1);
            return;
          }
          ctx.fillStyle = `${t.color}${t.life * 0.2})`;
          ctx.beginPath();
          ctx.arc(t.x, t.y, t.size * t.life, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [settings]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
    />
  );
};

export default BackgroundEffects;
