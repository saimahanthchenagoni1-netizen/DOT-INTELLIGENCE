
import React, { useState } from 'react';
import { QuizDifficulty, QuizType, QuizQuestion } from '../types';
import { generateQuiz } from '../services/geminiService';
import { Icons } from '../constants';

interface QuizProps {
  context: string;
  onQuizComplete: (questions: QuizQuestion[], answers: Record<number, string>) => void;
  onExit: () => void;
}

const Quiz: React.FC<QuizProps> = ({ context, onQuizComplete, onExit }) => {
  const [step, setStep] = useState<'config' | 'loading' | 'active'>('config');
  const [config, setConfig] = useState({
    count: 5,
    difficulty: QuizDifficulty.MEDIUM,
    type: QuizType.MULTIPLE_CHOICE,
    grade: '10'
  });
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});

  const startQuiz = async () => {
    setStep('loading');
    try {
      const generated = await generateQuiz(context, config.count, config.difficulty, config.type, config.grade);
      setQuestions(generated);
      setStep('active');
    } catch (err) {
      alert("Failed to generate quiz.");
      setStep('config');
    }
  };

  const handleNext = () => {
    if (currentQuestionIdx < questions.length - 1) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      onQuizComplete(questions, answers);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-12 px-6 animate-in slide-in-from-bottom-8 duration-500 relative">
      <div className="absolute top-4 right-6">
         <button 
           onClick={onExit}
           className="p-3 bg-white/5 hover:bg-red-500/20 hover:text-red-500 rounded-2xl transition-all"
           title="Exit Quiz"
         >
           <Icons.X />
         </button>
      </div>

      {step === 'config' && (
        <div className="glass-card p-12 rounded-[3rem] shadow-2xl">
          <h2 className="text-3xl font-black text-white mb-8 tracking-tighter">Challenge Mode</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-white/40 uppercase mb-2">Question Count</label>
              <input 
                type="number" 
                value={config.count} 
                onChange={e => setConfig({...config, count: Number(e.target.value)})}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white outline-none focus:border-cyan-500 transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-white/40 uppercase mb-2">Difficulty</label>
                <select 
                  value={config.difficulty} 
                  onChange={e => setConfig({...config, difficulty: e.target.value as QuizDifficulty})}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white outline-none focus:border-cyan-500 transition-all"
                >
                  <option value={QuizDifficulty.EASY}>Easy</option>
                  <option value={QuizDifficulty.MEDIUM}>Medium</option>
                  <option value={QuizDifficulty.HARD}>Hard</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-white/40 uppercase mb-2">Type</label>
                <select 
                  value={config.type} 
                  onChange={e => setConfig({...config, type: e.target.value as QuizType})}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white outline-none focus:border-cyan-500 transition-all"
                >
                  <option value={QuizType.MULTIPLE_CHOICE}>Multiple Choice</option>
                  <option value={QuizType.WRITING}>Free Text</option>
                </select>
              </div>
            </div>

            <button 
              onClick={startQuiz}
              className="w-full py-5 bg-white text-black font-black rounded-2xl hover:bg-cyan-400 transition-all shadow-xl mt-8"
            >
              START QUIZ
            </button>
          </div>
        </div>
      )}

      {step === 'loading' && (
        <div className="flex flex-col items-center justify-center py-40">
          <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mb-8"></div>
          <p className="text-2xl font-black text-white/40 animate-pulse uppercase tracking-widest">Crafting Challenges...</p>
        </div>
      )}

      {step === 'active' && (
        <div className="glass-card p-12 rounded-[3rem] shadow-2xl">
          <div className="flex justify-between items-center mb-10">
            <span className="text-cyan-400 font-black uppercase tracking-widest text-xs">Question {currentQuestionIdx + 1} of {questions.length}</span>
            <div className="w-48 h-2 bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all" 
                style={{ width: `${((currentQuestionIdx + 1) / questions.length) * 100}%` }}
              />
            </div>
          </div>

          <h3 className="text-3xl font-black text-white mb-10 leading-tight">{questions[currentQuestionIdx].question}</h3>

          <div className="space-y-4 mb-12">
            {config.type === QuizType.MULTIPLE_CHOICE ? (
              questions[currentQuestionIdx].options?.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => setAnswers({...answers, [questions[currentQuestionIdx].id]: opt})}
                  className={`w-full text-left p-6 rounded-2xl border-2 transition-all font-bold ${
                    answers[questions[currentQuestionIdx].id] === opt 
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400' 
                      : 'bg-black/40 border-white/5 text-white/40 hover:border-white/20'
                  }`}
                >
                  {opt}
                </button>
              ))
            ) : (
              <textarea 
                className="w-full bg-black/40 border-2 border-white/5 rounded-3xl p-8 text-white h-48 focus:border-cyan-500 outline-none transition-all text-xl"
                placeholder="Type your answer here..."
                value={answers[questions[currentQuestionIdx].id] || ''}
                onChange={(e) => setAnswers({...answers, [questions[currentQuestionIdx].id]: e.target.value})}
              />
            )}
          </div>

          <button
            onClick={handleNext}
            disabled={!answers[questions[currentQuestionIdx].id]}
            className="w-full py-5 bg-white text-black font-black rounded-2xl hover:bg-neutral-200 transition-all disabled:opacity-20 shadow-xl"
          >
            {currentQuestionIdx === questions.length - 1 ? 'FINISH' : 'NEXT'}
          </button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
