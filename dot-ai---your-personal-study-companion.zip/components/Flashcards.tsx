
import React, { useState } from 'react';
import { Flashcard } from '../types';
import { Icons } from '../constants';

interface FlashcardsProps {
  cards: Flashcard[];
  onExit: () => void;
}

const Flashcards: React.FC<FlashcardsProps> = ({ cards, onExit }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const card = cards[currentIdx];

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIdx((prev) => (prev + 1) % cards.length);
    }, 150);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIdx((prev) => (prev - 1 + cards.length) % cards.length);
    }, 150);
  };

  return (
    <div className="max-w-3xl mx-auto py-20 px-6 h-full flex flex-col relative">
      <div className="absolute top-4 right-6">
         <button onClick={onExit} className="p-3 bg-white/5 hover:bg-red-500/20 hover:text-red-500 rounded-2xl transition-all"><Icons.X /></button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="mb-12 text-center">
          <span className="px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full text-xs font-black text-purple-400 uppercase tracking-widest">Card {currentIdx + 1} of {cards.length}</span>
        </div>

        <div 
          onClick={() => setIsFlipped(!isFlipped)}
          className="relative w-full max-w-xl aspect-[4/3] cursor-pointer group perspective"
        >
          <div className={`w-full h-full transition-all duration-500 preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
            {/* Front */}
            <div className="absolute inset-0 backface-hidden glass-card rounded-[3rem] p-12 flex items-center justify-center text-center">
              <h2 className="text-4xl font-black text-white leading-tight">{card.front}</h2>
              <p className="absolute bottom-10 text-xs font-bold text-white/20 uppercase tracking-[0.3em]">Click to Flip</p>
            </div>
            {/* Back */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 glass-card rounded-[3rem] p-12 flex items-center justify-center text-center bg-white/5">
              <p className="text-2xl font-medium text-white/80 leading-relaxed">{card.back}</p>
            </div>
          </div>
        </div>

        <div className="mt-16 flex items-center gap-8">
          <button onClick={handlePrev} className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 transition-all">←</button>
          <button onClick={handleNext} className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 transition-all">→</button>
        </div>
      </div>
    </div>
  );
};

export default Flashcards;
