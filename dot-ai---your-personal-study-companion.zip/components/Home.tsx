
import React, { useState, useRef, useEffect } from 'react';
import { Icons } from '../constants';
import { explainContent, getChatSession } from '../services/geminiService';
import { ChatMessage } from '../types';

interface HomeProps {
  userName: string;
  onContentProcessed: (content: string, explanation: string) => void;
  onActionRequest: (type: 'quiz' | 'flashcards', context: string) => void;
}

const Home: React.FC<HomeProps> = ({ userName, onContentProcessed, onActionRequest }) => {
  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [attachment, setAttachment] = useState<{ data: string; mimeType: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isProcessing]);

  const speak = (text: string) => {
    if (!isVoiceMode) return;
    window.speechSynthesis.cancel(); // Cancel any current speech
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        const data = readerEvent.target?.result as string;
        setAttachment({ data, mimeType: file.type });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendMessage = async (customMsg?: string) => {
    const textToSend = customMsg || inputText;
    if (!textToSend.trim() && !attachment) return;
    
    const userMsg = textToSend.trim() || (attachment ? "Analyze this file for me." : "");
    const newMessages: ChatMessage[] = [...messages, { role: 'user', text: userMsg }];
    setMessages(newMessages);
    setInputText('');
    setIsProcessing(true);

    try {
      let responseText = "";
      if (messages.length === 0 && attachment) {
        responseText = await explainContent(userMsg, attachment);
        setAttachment(null);
      } else {
        const chat = getChatSession(newMessages);
        const result = await chat.sendMessage({ message: userMsg });
        responseText = result.text || "I'm sorry, I couldn't process that.";
      }
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
      speak(responseText);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', text: "Service temporarily unavailable. Please check your connection." }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[92vh] flex flex-col pt-8 px-8 relative z-10">
      <div className="flex justify-end mb-4">
        <button 
          onClick={() => {
            if (isVoiceMode) window.speechSynthesis.cancel();
            setIsVoiceMode(!isVoiceMode);
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all border font-black text-[10px] tracking-widest ${
            isVoiceMode ? 'bg-white text-black border-white shadow-lg' : 'bg-transparent text-gray-500 border-white/10'
          }`}
        >
          <Icons.Mic /> {isVoiceMode ? 'VOICE ON' : 'VOICE OFF'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pr-4 space-y-12 pb-56 no-scrollbar">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col justify-center items-center text-center animate-in fade-in zoom-in duration-1000">
             <div className="w-20 h-20 bg-[#111] border border-white/10 rounded-[2rem] mb-10 shadow-2xl flex items-center justify-center">
               <div className="dot-logo-circle"></div>
             </div>
             <h1 className="text-7xl font-black text-white mb-6 tracking-tighter">
              Hey, <span className="gradient-text">{userName}</span>
            </h1>
            <p className="text-gray-400 text-xl font-medium max-w-xl mx-auto leading-relaxed px-4">
              Snap a photo, paste the text of your question, share a YouTube link, or upload a document. Anything I can help you with today?
            </p>
            
            <div className="mt-12 w-full max-w-2xl grid grid-cols-2 md:grid-cols-4 gap-4">
               <button onClick={() => fileInputRef.current?.click()} className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 hover:border-white/20 transition-all active:scale-95">
                 <div className="p-3 bg-white/5 rounded-xl"><Icons.Camera /></div>
                 <span className="text-[9px] font-black uppercase tracking-widest text-gray-500">Snap Photo</span>
               </button>
               <button onClick={() => setInputText("Here is my question: ")} className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 hover:border-white/20 transition-all active:scale-95">
                 <div className="p-3 bg-white/5 rounded-xl"><Icons.Analyze /></div>
                 <span className="text-[9px] font-black uppercase tracking-widest text-gray-500">Paste Text</span>
               </button>
               <button onClick={() => setInputText("Analyze this YouTube video: ")} className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 hover:border-white/20 transition-all active:scale-95">
                 <div className="p-3 bg-white/5 rounded-xl"><Icons.Youtube /></div>
                 <span className="text-[9px] font-black uppercase tracking-widest text-gray-500">YouTube Link</span>
               </button>
               <button onClick={() => fileInputRef.current?.click()} className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 hover:border-white/20 transition-all active:scale-95">
                 <div className="p-3 bg-white/5 rounded-xl"><Icons.Paperclip /></div>
                 <span className="text-[9px] font-black uppercase tracking-widest text-gray-500">Document</span>
               </button>
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-4 duration-500`}>
              <div className={`max-w-[85%] rounded-[2.5rem] p-8 ${
                msg.role === 'user' 
                ? 'bg-white text-black font-bold shadow-2xl' 
                : 'glass-card text-gray-200 border-white/5'
              }`}>
                <div className="text-lg whitespace-pre-wrap">{msg.text}</div>
                
                {msg.role === 'model' && (
                  <div className="mt-8 flex flex-wrap gap-3 animate-in fade-in duration-1000 delay-300">
                    <button 
                      onClick={() => onActionRequest('quiz', msg.text)}
                      className="flex items-center gap-2 px-6 py-3 bg-white text-black rounded-xl text-[10px] font-black shadow-lg hover:bg-neutral-200 transition-colors"
                    >
                      <Icons.Quiz /> TAKE QUIZ
                    </button>
                    <button 
                      onClick={() => onActionRequest('flashcards', msg.text)}
                      className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black text-white hover:bg-white/10 transition-colors"
                    >
                      <Icons.Flashcards /> CARDS
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
        {isProcessing && (
          <div className="flex justify-start">
            <div className="bg-[#111] p-6 rounded-[1.5rem] border border-white/5 flex gap-2">
              <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-150"></div>
              <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-300"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="fixed bottom-12 left-1/2 -translate-x-1/2 w-full max-w-3xl px-8">
        <div className="glass shadow-2xl rounded-[3rem] p-4 glowing-input flex items-center gap-4 border-white/5">
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*,.pdf,.doc,.docx" />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="p-3 hover:bg-white/5 rounded-2xl text-gray-500 hover:text-white transition-colors"
          >
            <Icons.Paperclip />
          </button>
          
          <input 
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask Dot anything..."
            className="flex-1 bg-transparent text-white text-lg font-medium focus:outline-none placeholder-gray-700"
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={isProcessing || (!inputText.trim() && !attachment)}
            className="bg-white text-black p-4 rounded-2xl shadow-2xl active:scale-95 disabled:opacity-20 transition-all flex items-center justify-center"
          >
            <Icons.Send />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
