
import React from 'react';
import { Icons } from '../constants';

interface SidebarProps {
  onNavigate: (view: string) => void;
  activeView: string;
  isCollapsed: boolean;
  setIsCollapsed: (v: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onNavigate, activeView, isCollapsed, setIsCollapsed }) => {
  const menuItems = [
    { id: 'home', label: 'Home', icon: Icons.Home },
    { id: 'quizzes', label: 'Quizzes', icon: Icons.Quiz },
    { id: 'study', label: 'Guides', icon: Icons.Study },
    { id: 'flashcards', label: 'Cards', icon: Icons.Flashcards },
    { id: 'settings', label: 'Settings', icon: Icons.Settings },
  ];

  return (
    <div className="sidebar-float">
      <div 
        className="glass border border-white/10 flex flex-col items-center py-4 px-2 rounded-[2rem] transition-all duration-500 shadow-2xl w-14"
      >
        <div 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="mb-6 cursor-pointer flex items-center justify-center w-10 h-10 bg-[#111] rounded-xl border border-white/5 shadow-inner"
        >
          <div className="dot-logo-circle !w-2 !h-2"></div>
        </div>

        <nav className="space-y-3">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all group relative ${
                  isActive 
                    ? 'bg-white text-black shadow-lg' 
                    : 'text-gray-500 hover:text-white hover:bg-white/5'
                }`}
                title={item.label}
              >
                <div className="transition-transform duration-300 group-hover:scale-110 scale-90">
                  <Icon />
                </div>
                {isActive && (
                  <div className="absolute -right-1 w-0.5 h-0.5 bg-white rounded-full"></div>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
