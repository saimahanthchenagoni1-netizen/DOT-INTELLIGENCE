
import React, { useState } from 'react';
import { QuizQuestion } from '../types';
import { analyzeResults } from '../services/geminiService';
import { Icons } from '../constants';

interface ResultsProps {
  questions: QuizQuestion[];
  answers: Record<number, string>;
  onBackToHome: () => void;
}

const Results: React.FC<ResultsProps> = ({ questions, answers, onBackToHome }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{ analysis: string, studyGuide: string } | null>(null);
  const [reviewIdx, setReviewIdx] = useState(0);

  const calculateScore = () => {
    let score = 0;
    questions.forEach(q => {
      if (answers[q.id]?.toLowerCase().trim() === q.correctAnswer.toLowerCase().trim()) {
        score++;
      }
    });
    return score;
  };

  const score = calculateScore();
  const percentage = (score / questions.length) * 100;

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const res = await analyzeResults(questions, answers);
      setAnalysisResult(res);
    } catch (err) {
      alert("Failed to analyze.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const currentQ = questions[reviewIdx];
  const isCorrect = answers[currentQ.id]?.toLowerCase().trim() === currentQ.correctAnswer.toLowerCase().trim();

  return (
    <div className="max-w-4xl mx-auto p-8 pb-32 flex flex-col gap-10">
      <div className="bg-[#111] rounded-[3rem] p-12 border border-white/5 text-center shadow-2xl">
        <h2 className="text-4xl font-black text-white mb-2">Quiz Summary</h2>
        <div className="flex items-center justify-center gap-12 my-10">
          <div className="text-center">
            <p className="text-6xl font-black text-white">{score}/{questions.length}</p>
            <p className="text-gray-500 uppercase tracking-widest text-[10px] font-bold mt-2">Score</p>
          </div>
          <div className="w-px h-16 bg-white/10"></div>
          <div className="text-center">
            <p className="text-6xl font-black text-white">{Math.round(percentage)}%</p>
            <p className="text-gray-500 uppercase tracking-widest text-[10px] font-bold mt-2">Success</p>
          </div>
        </div>
        
        {!analysisResult && (
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="bg-white text-black font-black px-12 py-5 rounded-2xl flex items-center gap-3 mx-auto shadow-xl hover:scale-105 active:scale-95 transition-all"
          >
            {isAnalyzing ? <div className="w-6 h-6 border-2 border-black border-t-transparent rounded-full animate-spin"></div> : <Icons.Analyze />}
            AI FEEDBACK
          </button>
        )}
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-xl font-black text-white">Review Questions</h3>
          <div className="flex gap-4">
            <button onClick={() => setReviewIdx(Math.max(0, reviewIdx - 1))} className="w-12 h-12 flex items-center justify-center bg-white/5 rounded-full hover:bg-white/10 disabled:opacity-20" disabled={reviewIdx === 0}>←</button>
            <span className="flex items-center text-gray-500 font-bold">{reviewIdx + 1} of {questions.length}</span>
            <button onClick={() => setReviewIdx(Math.min(questions.length - 1, reviewIdx + 1))} className="w-12 h-12 flex items-center justify-center bg-white/5 rounded-full hover:bg-white/10 disabled:opacity-20" disabled={reviewIdx === questions.length - 1}>→</button>
          </div>
        </div>

        <div className="glass-card rounded-[2.5rem] p-10 border-white/5 min-h-[400px] flex flex-col">
          <div className="flex justify-between items-start mb-10">
            <h4 className="text-2xl font-bold text-white max-w-xl">{currentQ.question}</h4>
            <span className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest ${isCorrect ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
              {isCorrect ? 'Correct' : 'Incorrect'}
            </span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div className="p-6 bg-black rounded-[1.5rem] border border-white/5">
              <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mb-2">You Said</p>
              <p className={`text-lg font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>{answers[currentQ.id] || "Skipped"}</p>
            </div>
            {!isCorrect && (
              <div className="p-6 bg-black rounded-[1.5rem] border border-white/5">
                <p className="text-gray-500 text-[10px] font-black uppercase tracking-widest mb-2">Answer Key</p>
                <p className="text-lg font-bold text-white">{currentQ.correctAnswer}</p>
              </div>
            )}
          </div>
          
          <div className="flex-1 p-8 bg-white/5 rounded-[2rem] border border-white/5">
            <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-3">Dot's Insight</p>
            <p className="text-gray-200 leading-relaxed">{currentQ.explanation}</p>
          </div>
        </div>
      </div>

      {analysisResult && (
        <div className="space-y-12 animate-in slide-in-from-bottom-10 duration-700">
          <div className="glass-card rounded-[3rem] p-12 border-white/5">
            <h3 className="text-2xl font-black text-white mb-6">Deep Analysis</h3>
            <div className="text-gray-300 whitespace-pre-wrap">{analysisResult.analysis}</div>
          </div>
          <div className="glass-card rounded-[3rem] p-12 border-white/5">
            <h3 className="text-2xl font-black text-white mb-6">Study Guide</h3>
            <div className="text-gray-300 whitespace-pre-wrap">{analysisResult.studyGuide}</div>
          </div>
          <button onClick={onBackToHome} className="w-full py-6 bg-white text-black font-black rounded-3xl text-xl shadow-2xl">FINISH REVIEW</button>
        </div>
      )}
    </div>
  );
};

export default Results;
